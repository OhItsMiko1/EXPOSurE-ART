import { createContext, useContext, useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Define the User type
type User = {
  id: number;
  username: string;
  email: string;
  isArtist: boolean;
  fullName: string;
  profileImage?: string;
  isAdmin?: boolean;
};

// Auth context type
type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  login: (username: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
};

// Registration data
type RegisterData = {
  username: string;
  password: string;
  email: string;
  fullName: string;
  isArtist?: boolean;
};

// Create the context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  error: null,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
  checkAuth: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Check authentication status on component mount
  useEffect(() => {
    checkAuth();
  }, []);

  // Function to check if user is logged in
  const checkAuth = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest("GET", "/api/users/me");
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      } else {
        setUser(null);
      }
    } catch (err) {
      console.error("Auth check error:", err);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Login function
  const login = async (username: string, password: string) => {
    setError(null);
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/users/login", { username, password });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        setLocation("/");
        toast({
          title: "Login successful",
          description: `Welcome back, ${userData.fullName || userData.username}!`,
        });
      } else {
        const data = await response.json();
        setError(data.message || "Invalid username or password");
        toast({
          variant: "destructive",
          title: "Login failed",
          description: data.message || "Invalid username or password",
        });
      }
    } catch (err) {
      console.error("Login error:", err);
      setError("An unexpected error occurred. Please try again.");
      toast({
        variant: "destructive",
        title: "Login error",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Register function
  const register = async (userData: RegisterData) => {
    setError(null);
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/users/register", userData);
      
      if (response.ok) {
        const newUser = await response.json();
        setUser(newUser);
        setLocation("/");
        toast({
          title: "Registration successful",
          description: `Welcome to EXPOSurE.ART, ${newUser.fullName || newUser.username}!`,
        });
      } else {
        const data = await response.json();
        setError(data.message || "Registration failed. Please try again.");
        toast({
          variant: "destructive",
          title: "Registration failed",
          description: data.message || "Registration failed. Please try again.",
        });
      }
    } catch (err) {
      console.error("Registration error:", err);
      setError("An unexpected error occurred. Please try again.");
      toast({
        variant: "destructive",
        title: "Registration error",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    setError(null);
    try {
      const response = await apiRequest("POST", "/api/users/logout");
      
      if (response.ok) {
        setUser(null);
        setLocation("/login");
        toast({
          title: "Logout successful",
          description: "You have been logged out successfully.",
        });
      } else {
        const data = await response.json();
        toast({
          variant: "destructive",
          title: "Logout failed",
          description: data.message || "Logout failed. Please try again.",
        });
      }
    } catch (err) {
      console.error("Logout error:", err);
      toast({
        variant: "destructive",
        title: "Logout error",
        description: "An unexpected error occurred. Please try again.",
      });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        error,
        login,
        register,
        logout,
        checkAuth,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to use the auth context
export const useAuth = () => useContext(AuthContext);